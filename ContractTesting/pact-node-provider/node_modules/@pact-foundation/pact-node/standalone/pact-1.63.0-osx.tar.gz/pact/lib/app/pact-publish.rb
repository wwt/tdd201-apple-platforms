puts "ERROR: The `pact-publish` command has been moved to `pact-broker publish`. We apologise for any inconvenience caused."
exit(1)
